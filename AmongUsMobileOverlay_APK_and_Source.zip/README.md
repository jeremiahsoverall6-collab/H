# Among Us Mobile Overlay — Android companion prototype

This Android Studio project builds a small, draggable overlay companion for the **official Among Us Android app**.

## Current functionality
- Android overlay permission flow
- Draggable floating panel
- Demo key field prefilled with `55` (not a real CrewCore key)
- HOME / PLAYERS / SETTINGS preview tabs
- Button to launch the official Among Us app (`com.innersloth.spacemafia`)
- UI-only preview buttons for free-chat status, player list and customization

## Important integration boundary
The official Among Us Android app does not expose a public API for external apps to change its internal gameplay, account permissions, free-chat eligibility, or player state. This project therefore launches the official game and displays an independent overlay; its preview controls do not claim to alter the game. It does not collect Among Us credentials or bypass account/security checks.

## Build locally
1. Install Android Studio and Android SDK Platform 35.
2. Open this project folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build → Build APK(s)**.
5. Android Studio creates the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.

The project uses Android Gradle Plugin 8.7.3, Gradle 8.9 and JDK 17.

## Build a ZIP that contains both the APK and source
A GitHub Actions workflow is included at `.github/workflows/android-apk.yml`. Push this project to a GitHub repository, then run the **Build Android APK** workflow from the Actions tab (or push to `main` / `master`). The workflow builds the APK and uploads one ZIP containing:
- `AmongUsMobileOverlay.apk`
- project source
- README

## Install and use
1. Install the generated APK on your Android phone.
2. Open Crew Menu and grant **Display over other apps** permission.
3. Start the floating menu.
4. Tap **Open Among Us** to launch the official game.
5. Drag the menu using its header. Use **Close overlay** to dismiss it.

Package: `com.example.amongusoverlay`
