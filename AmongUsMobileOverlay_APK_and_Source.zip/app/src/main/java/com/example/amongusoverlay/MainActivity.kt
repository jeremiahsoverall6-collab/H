package com.example.amongusoverlay

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        layout.addView(TextView(this).apply {
            text = "Crew Menu • Mobile Overlay"
            textSize = 23f
        })
        layout.addView(TextView(this).apply {
            text = "A companion overlay for the official Among Us Android app. It does not modify game files or access your account."
            textSize = 15f
            setPadding(0, 12, 0, 20)
        })
        layout.addView(Button(this).apply {
            text = "Grant display-over-other-apps permission"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "Start floating menu"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                    finish()
                } else {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "Open official Among Us"
            setOnClickListener { launchAmongUs() }
        })
        setContentView(layout)
    }

    private fun launchAmongUs() {
        val launchIntent = packageManager.getLaunchIntentForPackage("com.innersloth.spacemafia")
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launchIntent)
        } else {
            android.widget.Toast.makeText(
                this,
                "Among Us was not found. Install the official game first.",
                android.widget.Toast.LENGTH_LONG
            ).show()
        }
    }
}
