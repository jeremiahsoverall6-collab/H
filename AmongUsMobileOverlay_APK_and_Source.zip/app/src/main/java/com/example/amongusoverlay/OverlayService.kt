package com.example.amongusoverlay

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel == null) showOverlay()
        return START_NOT_STICKY
    }

    private fun showOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12)
            setBackgroundColor(Color.rgb(25, 28, 38))
        }
        val header = TextView(this).apply {
            text = "● CREW MENU     DRAG HERE"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(6, 10, 6, 14)
        }
        root.addView(header)

        val status = TextView(this).apply {
            text = "Overlay connected • Game features are UI previews"
            setTextColor(Color.LTGRAY)
            textSize = 12f
            setPadding(4, 4, 4, 10)
        }
        root.addView(status)

        val keyLabel = TextView(this).apply {
            text = "Demo key"
            setTextColor(Color.LTGRAY)
        }
        root.addView(keyLabel)
        root.addView(EditText(this).apply {
            setText("55")
            textSize = 16f
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setHint("Enter key")
        })

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("HOME", "PLAYERS", "SETTINGS").forEach { tab ->
            tabs.addView(Button(this).apply {
                text = tab
                textSize = 10f
                setOnClickListener { status.text = "$tab • companion interface preview" }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(tabs)

        root.addView(Button(this).apply {
            text = "Open Among Us"
            setOnClickListener {
                val launchIntent = packageManager.getLaunchIntentForPackage("com.innersloth.spacemafia")
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(launchIntent)
                    status.text = "Launching official Among Us"
                } else {
                    status.text = "Among Us not found on this device"
                }
            }
        })
        listOf("Free chat status • preview", "Player list • preview", "Customization • preview").forEach { item ->
            root.addView(Button(this).apply {
                text = item
                setOnClickListener { status.text = "$item — not connected to game internals" }
            })
        }
        root.addView(Button(this).apply {
            text = "Close overlay"
            setOnClickListener { stopSelf() }
        })

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            0,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 120
        }

        header.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = lp.x
                        startY = lp.y
                        touchX = event.rawX
                        touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = startX + (event.rawX - touchX).toInt()
                        lp.y = startY + (event.rawY - touchY).toInt()
                        wm.updateViewLayout(root, lp)
                        return true
                    }
                }
                return false
            }
        })

        panel = root
        wm.addView(root, lp)
    }

    override fun onDestroy() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }
}
